import commonStyles from './CommonStyles';

export default commonStyles;
